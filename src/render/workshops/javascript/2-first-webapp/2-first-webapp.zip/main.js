var outputElem = document.querySelector('#output');

outputElem.innerHTML = '2 + 2 = 4';